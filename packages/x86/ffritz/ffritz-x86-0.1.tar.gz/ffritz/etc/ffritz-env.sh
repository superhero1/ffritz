export FFRITZ_HOME=/var/media/ftp/ffritz
export LD_LIBRARY_PATH=$FFRITZ_HOME/lib
